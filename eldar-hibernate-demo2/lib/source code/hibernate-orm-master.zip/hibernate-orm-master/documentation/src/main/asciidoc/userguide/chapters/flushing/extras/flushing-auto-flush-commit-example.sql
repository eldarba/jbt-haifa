--INFO: Entity is in persisted state
INSERT INTO Person (name, id) VALUES ('John Doe', 1)