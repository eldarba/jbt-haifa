import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/products';
import { ActivatedRoute } from '@angular/router';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  public product:Product;

  constructor(private activatedRoute: ActivatedRoute, private productService: ProductsService) { }

  ngOnInit() {
    this.productService.getAllProductsAsynch().subscribe(products=>{
      const id = this.activatedRoute.snapshot.params.id;
      this.product = products.find(p => p.id == id);
    }, err=>{
      alert("Error: " + err);
    });
    
  }

}
