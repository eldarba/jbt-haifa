import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ProductsService } from 'src/app/services/products.service';
import { Product } from 'src/app/models/products';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  public products: Product[];

  constructor(private title: Title, private productsService: ProductsService) { } // DI

  ngOnInit() {
    this.title.setTitle("Our Products"); // set the title

    // קריאה סינכרונית
    // this.products =  this.productsService.getAllProducts();

    // קריאה אסינכרונית טכניקה ראשונה
    // this.productsService.getAllProductsAsynch1(
    //   // suply the success callback function
    //   (arr) => {
    //     this.products = arr;
    //   },
    //   // suply the fail callback function
    //   (err) => {
    //     console.log("Error: " + err);
    //   }
    // );
    // console.log("end");

    // קריאה אסינכרונית טכניקה שנייה
    // var promise: Promise<Product[]> = this.productsService.getAllProductsAsynch2();
    // promise.then(products => { this.products = products });
    // promise.catch(err => { alert("Error: " + err) });

    // this.productsService.getAllProductsAsynch2().then(products => {
    //   this.products = products
    // }).catch(err => {
    //   alert("Error: " + err)
    // });

    // קריאה אסינכרונית טכניקה שלישית
    // this.productsService.getAllProductsAsynch3().subscribe(products=>{
    //   this.products= products;
    // }, err=>{
    //   alert("Error: " + err);
    // });

    // הבאת מוצרים מהשרת
    this.productsService.getAllProductsAsynch().subscribe(products => {
      setTimeout(() => {
        this.products = products;
      }, 300);
    }, err => {
      alert("Error: " + err);
    });
  }

}
