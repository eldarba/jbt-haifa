import { Injectable } from '@angular/core';
import { Product } from '../models/products';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor() { }

  public getAllProducts(): Product[] { 
    // const x: number = 5;
    const arr: Product[] = [];
    arr.push(new Product(1, "Apple", 3.5, 100));
    arr.push(new Product(2, "Banana", 5.5, 200));
    arr.push(new Product(3, "Peach", 6, 50));
    return arr;
  }
  public getAllProductsAsynch1(successCallback, failureCallback): void { 

    setTimeout(function(){
      try{
        const arr: Product[] = [];
        arr.push(new Product(1, "Apple", 3.5, 100));
        arr.push(new Product(2, "Banana", 5.5, 200));
        arr.push(new Product(3, "Peach", 6, 50));
        successCallback(arr);
      }catch(err){
        failureCallback(err);
      }

    }, 3000);


  }


}
