import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public currentDiscount: number;
  public currentDate: Date;
  public imageWidth: number;

  constructor() { }

  ngOnInit() {
    this.currentDiscount = 5;
    this.currentDate = new Date();
    this.imageWidth = 300;

  }




}
