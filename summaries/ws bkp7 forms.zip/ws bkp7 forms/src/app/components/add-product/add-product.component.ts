import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/products';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  public product = new Product();

  constructor(private productService: ProductsService) { }

  ngOnInit() {
  }

  addProduct(){

    alert(`
    product name: ${this.product.name}
    product price: ${this.product.price}
    product stock: ${this.product.stock}
    `);

    // this.productService.addProduct(this.product).subscribe(p=>{
    //   alert("product has been added! product id is: " + p.id);
    // }, err=>{
    //   alert("Error: " + err);
    // })
  }

}
