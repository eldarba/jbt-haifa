import { Injectable } from '@angular/core';
import { Product } from '../models/products';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private httpClient:HttpClient) { }

  public getAllProducts(): Product[] {
    // const x: number = 5;
    const arr: Product[] = [];
    arr.push(new Product(1, "Apple", 3.5, 100));
    arr.push(new Product(2, "Banana", 5.5, 200));
    arr.push(new Product(3, "Peach", 6, 50));
    return arr;
  }

  public getAllProductsAsynch1(successCallback, failureCallback): void {
    setTimeout(function () {
      try {
        const arr: Product[] = [];
        arr.push(new Product(1, "Apple", 3.5, 100));
        arr.push(new Product(2, "Banana", 5.5, 200));
        arr.push(new Product(3, "Peach", 6, 50));
        successCallback(arr);
      } catch (err) {
        failureCallback(err);
      }
    }, 3000);
  }
 
  public getAllProductsAsynch2(): Promise<Product[]> {
    return new Promise((resolve, reject)=>{
      setTimeout(function () {
        try {
          const arr: Product[] = [];
          arr.push(new Product(1, "Apple", 3.5, 100));
          arr.push(new Product(2, "Banana", 5.5, 200));
          arr.push(new Product(3, "Peach", 6, 50));
          resolve(arr);
        } catch (err) {
          reject(err);
        }
      }, 3000);
    });
  }

  public getAllProductsAsynch3(): Observable<Product[]> {
    return Observable.create(observer =>{
      setTimeout(function () {
            try {
              const arr: Product[] = [];
              arr.push(new Product(1, "Apple", 3.5, 100));
              arr.push(new Product(2, "Banana", 5.5, 200));
              arr.push(new Product(3, "Peach", 6, 50));
              observer.next(arr); // 
            } catch (err) {
              observer.error(err);
            }
          }, 3000);
    });
  }
  public getAllProductsAsynch(): Observable<Product[]> {
    // return this.httpClient.get<Product[]>("http://localhost:8080/coupon-sys/rest/get-all-companies",{withCredentials: true});
    return this.httpClient.get<Product[]>("assets/json/products.json",{withCredentials: true});
    return Observable.create(observer =>{
      setTimeout(function () {
            try {
              const arr: Product[] = [];
              arr.push(new Product(1, "Apple", 3.5, 100));
              arr.push(new Product(2, "Banana", 5.5, 200));
              arr.push(new Product(3, "Peach", 6, 50));
              observer.next(arr); // 
            } catch (err) {
              observer.error(err);
            }
          }, 3000);
    });
  }

  public addProduct(product: Product): Observable<Product>{
    return this.httpClient.post<Product>("assets/json/products.json", product)
  }

}
