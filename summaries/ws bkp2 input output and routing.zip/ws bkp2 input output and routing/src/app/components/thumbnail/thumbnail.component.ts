import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent {

  @Input() // חושפים אותו מהסלקטור
  imageSource: string;

  @Output()
  imageClicked: EventEmitter<string> = new EventEmitter();

  imageHasBeenClicked(){
    this.imageClicked.emit(this.imageSource); // raising an evenet - דיווח אירוע
  }

}
